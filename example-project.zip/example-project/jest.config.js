/** @type {import('jest').Config} */
const config = {
	testMatch: ['**/*.spec.js'],
	verbose: true
};

export default config;
