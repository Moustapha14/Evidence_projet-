This folder needs to exist for SvelteKit to build correctly.

Components need to go into [packages/ui](../../../../packages/ui), utilities go into [packages/component-utilities](../../../../packages/component-utilities/).