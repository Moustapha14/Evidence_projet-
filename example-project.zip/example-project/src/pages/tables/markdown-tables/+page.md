---
title: Markdown Tables
sources:
  - orders_by_category: orders_by_category.sql
---

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?
<DataTable data={orders_by_category} />
Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

| Column One | Column Two | Column Three |
| :--------: | :--------: | :----------: |
|    100     |    100     |    1,004     |
|    2134    |    140     |    1,130     |

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?
