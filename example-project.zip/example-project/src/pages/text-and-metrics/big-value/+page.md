---
title: Big Value
sources:
  - orders_with_comparisons: orders_with_comparisons.sql
---

<BigValue 
data = {orders_with_comparisons} 
value=sales_usd0k
comparison=sales_change_pct0
comparisonTitle="vs. Last Month"
/>

<BigValue data = {orders_with_comparisons} 
value=aov_usd2
title="AOV ($)"
sparkline=month
comparison=aov_change_pct0
comparisonTitle="vs. Last Month"
/>

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

<LineChart
data = {orders_with_comparisons.filter(d => d.category === "Sinister Toys")}
y=sales_usd0k
yAxisTitle="Sales"
/>

## Uno sine at nunc pontus rectorque umeros

Est qui conciderant, parte haud effugit dixerat. Retentas Pelasga vivunt; Est qui conciderant, parte haud effugit dixerat. Retentas Pelasga vivunt;

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

Est qui conciderant, parte haud effugit dixerat. Retentas Pelasga vivunt;
attigimus restabat exitus. Praedaeque ademit. _Vix_ eundem, saevarum et nescia
inter retinentibus inaniter pontum! `pages/index.md`

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

# Error state
<BigValue 
data = {orders_with_comparisons} 
/>


## Pascua tigres inde

Domino cuncta dicenda. Serpente paludem et nubes Cithaeron alios mihi non.

- Cernit traxerunt oras devolvere opibusque gerit Tatiusque
- Aethere mihi pirithoi fontes concretaque hic obuncis
- Solitas fibras aures et verba hiatus et
- Secutum idonea
- Et vocem inquit
- Dum aequi Xanthique minantia nec taurum
