## Venn Diagram

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

<VennDiagram
labels={["Title A", "Title B", "Title C"]}
amounts={["AMOUNT A", "AMOUNT B", "AMOUNT C"]}
overlaps={["A", "AB", "BC", "AC", "ABC"]}
/>

Est qui conciderant, parte haud effugit dixerat. Retentas Pelasga vivunt;
attigimus restabat exitus. Praedaeque ademit. _Vix_ eundem, saevarum et nescia
inter retinentibus inaniter pontum! `pages/index.md`
