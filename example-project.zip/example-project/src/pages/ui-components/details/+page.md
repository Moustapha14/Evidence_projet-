## Details

<Details title="Definitions">
    Definition of metrics in Solutions Targets

    ### Time to Proposal

    Average number of days it takes to create a proposal for a customer

    *Calculation:*
    Sum of the number of days it took to create each proposal, divided by the number of proposals created

    *Source:*
    Hubspot
 </Details>

Lorem markdownum nivea redimitus. In rector in, flumine adimunt, cinctum, dolore
pallada senectus dixit? Crematisregia fetus Io locus viscera redde lucida
discede?

 <Details title="Metric Info">
    Definition of metrics in Solutions Targets

    ### Time to Proposal

    Average number of days it takes to create a proposal for a customer

    *Calculation:*
    Sum of the number of days it took to create each proposal, divided by the number of proposals created

    *Source:*
    Hubspot

| Column One | Column Two | Column Three |
| :--------: | :--------: | :----------: |
|    100     |    100     |    1,004     |
|    2134    |    140     |    1,130     |
 </Details>

 <Details title="Sources">    

    - **The Economist**: September 24,2015
    - **New York Times analysis on emissions**: October 12, 2016


 </Details>
