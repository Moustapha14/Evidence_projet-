## Link Button

<LinkButton url="/text-and-metrics/text"> Key and Metrics </LinkButton>
